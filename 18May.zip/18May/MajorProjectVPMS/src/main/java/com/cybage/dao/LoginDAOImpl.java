package com.cybage.dao;

import javax.crypto.SecretKey;
import javax.persistence.EntityManager;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import com.cybage.model.Userrole;
import com.cybage.service.Database;
import com.cybage.service.Messages;
import com.cybage.service.VerifyCredentials;

@Service
public class LoginDAOImpl implements LoginDAO {

	@Override
	public boolean validate(String username, byte[] encryptedPassword,
			HttpServletRequest request, SecretKey secretKey) {
		VerifyCredentials verifyCredentials = new VerifyCredentials();
		return verifyCredentials.validate(username, encryptedPassword, request,secretKey);
	}

	@Override
	public String checkRole(String username) {
		EntityManager entityManagerObject = Database.getEntityManager();
		try {
			Userrole g = (Userrole) entityManagerObject
					.createQuery(
							"select s from Userrole s where s.id =:chrName")
					.setParameter("chrName", username).getSingleResult();
			entityManagerObject.close();
			return g.getRole();
		} catch (Exception e) {
			entityManagerObject.close();
			return Messages.UNDEFINED_ROLES;
		}
	}

}
