package com.cybage.service;


import java.io.File;
import java.io.IOException;
import java.io.FileOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Properties;

import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.cybage.configuration.LoggerClass;
import com.cybage.configuration.PropertyClass;

public class SendMailAtDuplicate {
	private static LoggerClass loggerInstance = LoggerClass.getLoggerInstance();
	static PropertyClass propertyObject = new PropertyClass();
	public static void sendMail(String createdBy, String msg, ArrayList<String> duplicateInvoiceList) {
		try {
			String host = propertyObject.getMailHost();
			final String user = propertyObject.getMailerName();// change
																// accordingly
			final String password = propertyObject.getMailerPassword();// change
																		// accordingly

			String to = createdBy + propertyObject.getDomainPostFix();//change accordingly  
		  
		   //Get the session object  
		   Properties props = new Properties();  
		   props.put("mail.smtp.host",host);  
		   props.put("mail.smtp.auth", "true");  
		     
		   Session session = Session.getDefaultInstance(props,  
		    new javax.mail.Authenticator() {  
		      protected PasswordAuthentication getPasswordAuthentication() {  
		    return new PasswordAuthentication(user,password);  
		      }  
		    });  
		  
		   //Compose the message  
		     
		    	MimeMessage message = new MimeMessage(session);  
		        message.setFrom(new InternetAddress(user));  
		        message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));  
		        message.setSubject("CybageVPMS Duplicate Invoice Requests !!");
		        
		       
		        if(generateAttachment(msg,createdBy)){       
		        //3) create MimeBodyPart object and set your message text     
		        BodyPart messageBodyPart = new MimeBodyPart();     
		        String messageBody = "Hi "
						+ createdBy
						+ "<BR><BR> Your Requests for vendor payment found duplicate <BR><B>Please find attached file of duplicate request for more details."
						+ "<BR><BR> This is system generated mail.<B> DO NOT REPLY TO THIS MAIL</B><BR>Please contact Purchase Department for queries. <BR><BR> Thanks for your co-operation!!"
						+ "<BR><BR> Regards,<BR><BR><B> Cybage VPMS Team <BR><B> Cybage Software Pvt. Ltd. (An ISO 27001 Company) <BR><B> Pune, India ";
				messageBodyPart.setContent(messageBody, "text/html");
				
		        //5) create Multipart object and add MimeBodyPart objects to this object      
		        Multipart multipart = new MimeMultipart();  
		        multipart.addBodyPart(messageBodyPart);  
		        MimeBodyPart attachPart = new MimeBodyPart();
				
				LocalDate localDate = LocalDate.now();
				attachPart.attachFile(System.getProperty("user.dir")
						+ "\\InvalidFiles\\DuplicateInvoiceList" + localDate
						+ createdBy + ".xlsx");
				multipart.addBodyPart(attachPart);
		        //6) set the multiplart object to the message object  
		        message.setContent(multipart);  
		         
		        //7) send message 
		       
		        Transport.send(message);  
		}
		        else
		        	loggerInstance.logger.error("Something went wrogn");
		        
		        loggerInstance.logger.info("message sent...."); 
		        for(int i=0;i<duplicateInvoiceList.size();i++){
		    		SendMailAtDuplicate.updateStatus("Send",duplicateInvoiceList.get(i));
		    	}
		     } 
		    catch (MessagingException e)
		    {	
		    	for(int i=0;i<duplicateInvoiceList.size();i++){
		    		SendMailAtDuplicate.updateStatus("Not Send",duplicateInvoiceList.get(i));
		    	}		    	
		    	loggerInstance.logger.error(e);
		    } catch (IOException e) {
		    	for(int i=0;i<duplicateInvoiceList.size();i++){
		    		SendMailAtDuplicate.updateStatus("Not Send",duplicateInvoiceList.get(i));
		    	}		    	
		    	loggerInstance.logger.error(e);
			}  		
	}
	public static void updateStatus(String status, String id){
		EntityManager entityManagerObject=Database.getEntityManager();
		EntityTransaction updateTransaction = entityManagerObject.getTransaction();
		updateTransaction.begin();
		Query query = entityManagerObject.createQuery("UPDATE Invalidinvoiceinfo invalidinvoiceinfo SET invalidinvoiceinfo.mailStatus = ?1 "
		+ "WHERE invalidinvoiceinfo.invoiceNum= :num");
		query.setParameter(1, status);
		query.setParameter("num", id);
		int updateCount = query.executeUpdate();
		loggerInstance.logger.info(updateCount);
		updateTransaction.commit();
		entityManagerObject.close();
	}
	
	public static boolean generateAttachment(String msg,String createdBy){
		String[] splitArray = msg.split("#");
		boolean result = false;
		try {
			XSSFWorkbook workbook = new XSSFWorkbook();
			int rownum = 0;
			XSSFSheet sheet = workbook.createSheet("Worksheet");
			Row header = sheet.createRow(rownum++);
			int cellnum = 0;
			Cell headercellOne = header.createCell(cellnum++);
			headercellOne.setCellValue("Vendor Code");
			Cell headercellTwo = header.createCell(cellnum++);
			headercellTwo.setCellValue("Invoice Number");
			Cell headercellThree = header.createCell(cellnum++);
			headercellThree.setCellValue("Payment Amount");
			
			for(int index=0;index<splitArray.length;index+=4){
				Row row = sheet.createRow(rownum++);
				cellnum = 0;
				loggerInstance.logger.info(splitArray[index]);
				Cell cellOne = row.createCell(cellnum++);
				cellOne.setCellValue(splitArray[index]);
				Cell cellTwo = row.createCell(cellnum++);
				cellTwo.setCellValue(splitArray[index+1]);
				Cell cellThree = row.createCell(cellnum++);
				cellThree.setCellValue(splitArray[index+2]);
				result = true;
			}
			LocalDate localDate = LocalDate.now();
			FileOutputStream out = new FileOutputStream(new File(System.getProperty("user.dir")
					+ "\\InvalidFiles\\DuplicateInvoiceList"
					+ localDate + createdBy + ".xlsx"));
			workbook.write(out);
			out.close();
			loggerInstance.logger.info("File writing success");
		} catch (Exception e) {
			result = false;
			loggerInstance.logger.error(e);
		}
		return result;
	}
}