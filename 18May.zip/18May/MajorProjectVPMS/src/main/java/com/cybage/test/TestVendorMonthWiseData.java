package com.cybage.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.ModelAndView;

import com.cybage.configuration.LoggerClass;
import com.cybage.dao.AdminDAO;
import com.cybage.dao.AdminDAOImpl;
import com.cybage.model.Aggregateinvoiceinfo;
import com.cybage.service.AddToDB;
import com.cybage.service.Database;
import com.cybage.service.HistoricalDataCriteria;
import com.cybage.service.SendMailAtDuplicate;
import com.cybage.service.ValidateExcelFile;
import com.cybage.service.VendorHistory;

public class TestVendorMonthWiseData {
LoggerClass loggerInstance = LoggerClass.getLoggerInstance();
	@Test
	public void testVendorHistory() {
	//VendorHistory vendor = new VendorHistory();
	//loggerInstance.logger.info("USER DL="+Database.getAlluser().size());
	//assertNotNull(vendor.getVendorHistory(201125));
		//ArrayList<String> invoiceList = new ArrayList<String>();
		//invoiceList.add("17701");
//	SendMailAtDuplicate.sendMail("akashpuri","17701#ERS-18888888888-8488#4000#NEFT_2017-11-17_10.28.05.89#17701#ERS-18888888888-8488#4000#NEFT_2017-11-17_10.28.05.89#17701#ERS-18888888888-8488#4000#NEFT_2017-11-17_10.28.05.89#17701#ERS-18888888888-8488#4000#NEFT_2017-11-17_10.28.05.89",invoiceList);
	//System.out.println(Database.getProcessedRequestVendor().size());
	//AdminDAOImpl.checkForAveragePaymentCriteria((ArrayList<Aggregateinvoiceinfo>) Database.getProcessedRequestVendor());
	//new AdminDAOImpl().getPaymentDetails();
	//	ValidateExcelFile.validateFileByTableHeader();
	//	Database.addColumn("testColumn");
		ArrayList<String> list = ValidateExcelFile.getTableHeader();
		String str = AddToDB.getQueryPrefix(list);
		String str2 = AddToDB.getQueryPostfix(list.size());
		LoggerClass.logger.info(AddToDB.getQueryString(str, str2)+" "+str2.length());	
		new AddToDB().addExcelToDb("NEFT_2017-12-05_14.20.46.98",new ModelMap(),"akashpuri" );
	}
}