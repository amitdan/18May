package com.cybage.service;

import java.io.IOException;
import java.time.LocalDate;
import java.util.*;

import javax.mail.*;
import javax.mail.internet.*;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import com.cybage.configuration.PropertyClass;
import com.cybage.configuration.LoggerClass;
import com.cybage.model.Userrole;

public class SendMail {
	private static LoggerClass loggerInstance = LoggerClass.getLoggerInstance();

	public static void sendMail(ArrayList<String> dataList) {
		try {
			PropertyClass propertyObject = new PropertyClass();
			String host = propertyObject.getMailHost();
			final String user = propertyObject.getMailerName();// change
																// accordingly
			final String password = propertyObject.getMailerPassword();// change
																		// accordingly

			// Get the session object
			Properties props = new Properties();
			props.put("mail.smtp.host", host);
			props.put("mail.smtp.auth", "true");

			Session session = Session.getDefaultInstance(props,
					new javax.mail.Authenticator() {
						protected PasswordAuthentication getPasswordAuthentication() {
							return new PasswordAuthentication(user, password);
						}
					});
			loggerInstance.logger.debug("session created for mail"+session.getProperties().toString());
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(user));
			ArrayList<Userrole> mailDL = (ArrayList<Userrole>) Database
					.getAlluser();
			for (int index = 0; index < mailDL.size(); index++) {
				Userrole userObject = mailDL.get(index);
				if (userObject.getRole().equalsIgnoreCase("user")
						|| userObject.getRole().equalsIgnoreCase("admin")) {
					message.addRecipient(Message.RecipientType.TO,
							new InternetAddress(userObject.getId()
									+ propertyObject.getDomainPostFix()));
				loggerInstance.logger.info("Added recepient");
				}
					if (userObject.getRole().equalsIgnoreCase("superadmin")) {
						message.addRecipient(Message.RecipientType.CC,
								new InternetAddress(userObject.getId()
										+ propertyObject.getDomainPostFix()));
						loggerInstance.logger.info("Added CC");
					}
			}

			// 3) create MimeBodyPart object and set your message text
			MimeBodyPart messageBody = new MimeBodyPart();
			String messageBodyPart=null;
			String invoiceStatus = dataList.get(4);
			LocalDate localDate = LocalDate.now();
			if (invoiceStatus.equalsIgnoreCase("Approved")) {
				loggerInstance.logger.info("Added approved mail subject");
				message.setSubject(propertyObject.getApprovedSubject());
				messageBodyPart = "Hi <BR><BR> Request for vendor payment has been Approved.<BR> Following are details for request :"
								+ "<BR><BR> <B>Vendor Code:</B> "
								+ dataList.get(0)
								+ "<BR> <B>Vendor Name:</B> "
								+ dataList.get(1)
								+ "<BR><B> Payment Amount:</B>"
								+ dataList.get(2)
								+ "<BR><B> Rejected Amount: </B>"
								+ dataList.get(6)
								+ "<BR><B> Approved Date:</B> "
								+ localDate
								+ "<BR><BR> This is system generated mail.<B> DO NOT REPLY TO THIS MAIL</B><BR>Please contact Purchase Department for queries. <BR><BR> Thanks for your co-operation!!"
								+ "<BR><BR> Regards,<BR><BR><B> Cybage VPMS Team <BR><B> Cybage Software Pvt. Ltd. (An ISO 27001 Company) <BR><B> Pune, India ";
			loggerInstance.logger.info("Added mail body"+messageBodyPart);
			}
			if (invoiceStatus.equalsIgnoreCase("Heldback")) {
				loggerInstance.logger.info("Added heldback mail subject");
				message.setSubject(propertyObject.getHeldbackSubject());
				messageBodyPart = "Hi <BR><BR> Request for vendor payment has been put on hold.<BR>Following are details for request :"
								+ "<BR><BR> <B>Vendor Code:</B> "
								+ dataList.get(0)
								+ "<BR> <B> Vendor Name:</B> "
								+ dataList.get(1)
								+ "<BR> <B>Payment Amount:</B>"
								+ dataList.get(2)
								+ "<BR> <B> Rejected Amount:</B> "
								+ dataList.get(6)
								+ "<BR> <B> Remark:</B> "
								+ dataList.get(5)
								+ "<BR><BR> This is system generated mail.<B> DO NOT REPLY TO THIS MAIL</B><BR>Please contact Purchase Department for queries. <BR><BR> Thanks for your co-operation!!"
								+ "<BR><BR> Regards,<BR><BR><B> Cybage VPMS Team <BR><B> Cybage Software Pvt. Ltd. (An ISO 27001 Company) <BR><B> Pune, India ";
				loggerInstance.logger.info("Added mail body");
			}
			// 5) create Multipart object and add MimeBodyPart objects to this
			// object
			loggerInstance.logger.info("Created mail body of size = "+messageBody.getSize());
			Multipart multipart = new MimeMultipart();
			messageBody.setContent(messageBodyPart,"text/html");
			multipart.addBodyPart(messageBody);
			// 6) set the multiplart object to the message object
			
			message.setContent(multipart);

			// 7) send message
			Transport.send(message);
			loggerInstance.logger.info("message sent....");
			SendMail.checkStatus("Send", dataList.get(7).toString());
			loggerInstance.logger.debug("Updated status for id = "+dataList.get(7).toString());
		} catch (MessagingException e) {
			loggerInstance.logger
					.error("Exception generated during sending mail" + e);
			SendMail.checkStatus("Not Send", dataList.get(7).toString());
		} catch (IOException e) {
			loggerInstance.logger.error("Exception generated during reading property while sending mail" + e);
			SendMail.checkStatus("Not Send", dataList.get(7).toString());
		}
	}

	private static void checkStatus(String status, String id) {
		EntityManager entityManagerObject = Database.getEntityManager();
		EntityTransaction updateTransaction = entityManagerObject
				.getTransaction();
		updateTransaction.begin();
		Query query = entityManagerObject
				.createQuery("UPDATE Aggregateinvoiceinfo aggregateinvoiceinfo SET aggregateinvoiceinfo.mailStatus = ?1 "
						+ "WHERE aggregateinvoiceinfo.id= :num");
		query.setParameter(1, status);
		query.setParameter("num", Integer.parseInt(id));
		int updateCount = query.executeUpdate();
		loggerInstance.logger.info(updateCount);
		updateTransaction.commit();
		entityManagerObject.close();
	}

}