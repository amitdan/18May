package com.cybage.service;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.transaction.Transaction;

import com.cybage.model.Aggregateinvoiceinfo;
import com.cybage.model.Userrole;
import com.cybage.configuration.*;

public class Database {

	/** The property. */
	static PropertyClass property;
	
	/** The logger instance. */
	static LoggerClass loggerInstance;
	
	static Map<String,String> jpaProperties = new HashMap<String, String>();
	static{
		property = new PropertyClass();
		loggerInstance = LoggerClass.getLoggerInstance();
		try {
			jpaProperties.put(property.getHibernateConnection(),
					property.getDatabaseConnectionURL());
			jpaProperties.put(property.getHibernateDriverClass(),
					property.getDatabaseDriver());
			jpaProperties.put(property.getHibernateUsername(),
					property.getDatabaseUsername());
			jpaProperties.put(property.getHibernatePassword(),
					property.getDatabasePassword());
			jpaProperties.put(property.getHibernateAutodetect(),
					property.getDatabaseAutodetect());
			jpaProperties.put(property.getHibernateShowSql(),
					"false");
			jpaProperties.put(property.getHibernateFormatSql(),
					property.getDatabaseFormatSql());
			jpaProperties.put("hbm2ddl.auto", "update");
			jpaProperties.put("connection.release_mode", "auto");
			jpaProperties.put("hibernate.c3p0.testConnectionOnCheckout","true");
			/*
			 * <property name=”validationQuery” value=”SELECT 1″ />

<property name=”testOnBorrow” value=”true” />
<property name="hibernate.c3p0.testConnectionOnCheckout" value="true" />
			 */
			
		} catch (IOException e) {
			loggerInstance.logger.error(e);
			ExceptionHandling.invalidDatabaseConfiguration();
		}
	}
	
	private static EntityManagerFactory emFactory = Persistence.createEntityManagerFactory("MajorProjectVPMS",jpaProperties);
	public static EntityManager getEntityManager() {
		EntityManager entityManager=emFactory.createEntityManager();
		//entityManager.getEntityManagerFactory().getCache().evictAll();
		return entityManager;
	}
	
	@SuppressWarnings("unchecked")
	public static List<Userrole> getAlluser(){
		EntityManager entityManager = getEntityManager();
		return entityManager.createQuery("select s from Userrole s").getResultList();
	}
	
	@SuppressWarnings("unchecked")
	public static List<Aggregateinvoiceinfo> getProcessedRequestVendor(){
		EntityManager entityManager = getEntityManager();
		return entityManager.createQuery("select s from Aggregateinvoiceinfo s where s.invoiceStatus='Approved' and s.pane!='Satisfied Exception Criteria'").getResultList();
	}
	
	/*
	 ALTER TABLE `majorproject`.`invoiceinfo` 
ADD COLUMN `sampleCol` VARCHAR(45) NULL AFTER `vendorInvoiceNumber`;
	 */

	public static boolean addColumn(String columnName){
		boolean result = false;
		 try {
			 PropertyClass property = new PropertyClass();
			Class.forName(property.getDatabaseDriver());
			Connection connection = DriverManager.getConnection(property.getDatabaseConnectionURL(), property.getDatabaseUsername(),property.getDatabasePassword());
			Statement statement = connection.createStatement();
			String query = "ALTER TABLE `majorproject`.`invoiceinfo` ADD COLUMN `"+columnName+"` VARCHAR(200);";
			int rows = statement.executeUpdate(query);
			statement.close();
			connection.close();
			ValidateExcelFile.validateFileByTableHeader();
		 } catch (ClassNotFoundException e) {
			LoggerClass.logger.error(e);
		} catch (IOException e) {
			LoggerClass.logger.error(e);
		} catch (SQLException e) {
			LoggerClass.logger.error(e);
		}
		return result;
	}

	public static void addAveragePaymentRequest(String[] paymentIdArray) {
		try{
			EntityManager entityManager = getEntityManager();
			
			for(int index =0;index<paymentIdArray.length;index++){
				int paymentId = Integer.parseInt(paymentIdArray[index]);
				EntityTransaction txn = entityManager.getTransaction();
				txn.begin();
				String updateQuery = "Update Aggregateinvoiceinfo a set a.pane = 'Satisfied Average Payment Criteria', a.invoiceStatus='Processed' where a.id="+paymentId;
				Query query = entityManager.createQuery(updateQuery);
				int updateCount = query.executeUpdate();
				loggerInstance.logger.info("Updated pane for payment id = "+paymentId+"\n Affected row count ="+updateCount);
				txn.commit();
			}
			entityManager.close();
		}
		catch(Exception e){
			loggerInstance.logger.error(e);
		}
	}
}
