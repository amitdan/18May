package com.cybage.dao;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.ModelAndView;

import com.cybage.model.Aggregateinvoiceinfo;
import com.cybage.service.PaymentProcess;

@Service
public class SuperAdminDAOImpl implements SuperAdminDAO {

	@Override
	public ModelAndView viewheldback(int invoiceId, ModelMap model) {
		PaymentProcess paymentprocess = new PaymentProcess();

		List<Aggregateinvoiceinfo> listofInvoice = paymentprocess.listInvoice(
				invoiceId, model);
		ModelAndView modelObject = new ModelAndView("heldbackRequest");
		modelObject.addObject("file", listofInvoice);
		return modelObject;

	}

}
