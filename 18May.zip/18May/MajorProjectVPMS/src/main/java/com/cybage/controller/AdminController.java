package com.cybage.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import com.cybage.configuration.LoggerClass;
import com.cybage.dao.AdminDAO;
import com.cybage.model.*;
import com.cybage.service.*;

// TODO: Auto-generated Javadoc
/**
 * Handles requests for the application login page.
 * 
 */
@Controller
public class AdminController {

	/** The Constant logger. */
	private static LoggerClass loggerInstance = LoggerClass.getLoggerInstance();
	/** The admin dao. */
	@Autowired
	private AdminDAO adminDao;

	/** The file to update. */
	String fileToUpdate;

	/**
	 * View excel files.
	 * 
	 * @param login
	 *            the login
	 * @param model
	 *            the model
	 * @return the model and view
	 */
	@RequestMapping(value = "/viewExcelFilesbyAdmin", method = RequestMethod.GET)
	public ModelAndView viewExcelFiles(@ModelAttribute("login") Login login,
			ModelMap model) {

		ArrayList<Fileinfo> fileList = new ArrayList<Fileinfo>();
		fileList = adminDao.viewExcelFiles();
		loggerInstance.logger.info("List of file size = "+fileList.size());
		ModelAndView modelObject = new ModelAndView("viewExcelFilesbyAdmin");
		modelObject.addObject("file", fileList);
		return modelObject;

	}

	/**
	 * Adminhome.
	 * 
	 * @return the model and view
	 */
	@RequestMapping(value = "/adminHome", method = RequestMethod.GET)
	public ModelAndView adminhome() {
		loggerInstance.logger.info("Welcome to admin home");
		ModelAndView modelObject = new ModelAndView("adminHome");
		modelObject.addObject("value", "null");
		return modelObject;

	}

	/**
	 * Updateadmin.
	 * 
	 * @param filename
	 *            the filename
	 * @return the model and view
	 */
	@RequestMapping(value = "/updateFileByAdmin", method = RequestMethod.GET)
	public ModelAndView updateadmin(@RequestParam("filename") String filename) {
		loggerInstance.logger.info("updateadmin");
		fileToUpdate = filename;
		return new ModelAndView("updateFileAdmin");
	}

	/**
	 * Update excel file.
	 * 
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @param model
	 *            the model
	 * @return the model and view
	 */
	@RequestMapping(value = "/updateExcelFileAdmin", method = RequestMethod.POST)
	public ModelAndView updateExcelFile(HttpServletRequest request,
			HttpServletResponse response, ModelMap model) {
		loggerInstance.logger.info("file to update" + fileToUpdate);
		String checkFile = adminDao.updateExcelFile(request, response, model,
				fileToUpdate);
		ArrayList<Fileinfo> fileList = adminDao.viewExcelFiles();
		loggerInstance.logger.info(checkFile);
		ModelAndView modelObject = new ModelAndView("viewExcelFilesbyAdmin");
		modelObject.addObject("message", checkFile);
		modelObject.addObject("file", fileList);
		return modelObject;
	}

	/**
	 * Superadmin.
	 * 
	 * @return the model and view
	 */
	@RequestMapping(value = "/superAdmin1", method = RequestMethod.GET)
	public ModelAndView superadmin() {
		loggerInstance.logger.info("Redirected to superadmin Page");
		return new ModelAndView("superAdminHome");
	}

	/**
	 * Viewprocess file.
	 * 
	 * @param ID
	 *            the id
	 * @param createdBy
	 *            the created by
	 * @param model
	 *            the model
	 * @return the model and view
	 */
	@RequestMapping(value = "/processExcelFile", method = RequestMethod.GET)
	public ModelAndView viewprocessFile(@RequestParam("ID") String ID,
			@RequestParam("createdby") String createdBy, ModelMap model) {

		// gets the file name:
		String processExcelFile = adminDao.processFile(ID, createdBy, model);
		ArrayList<Fileinfo> fileList = adminDao.viewExcelFiles();
		ModelAndView modelObject = new ModelAndView("viewExcelFilesbyAdmin");
		modelObject.addObject("file", fileList);
		modelObject.addObject("message", processExcelFile);
		return modelObject;
	}

	/**
	 * Gets the payment details.
	 * 
	 * @param model
	 *            the model
	 * @return the payment details
	 */
	@RequestMapping(value = "/getPaymentDetails", method = RequestMethod.GET)
	public ModelAndView getPaymentDetails(ModelMap model) {
		return adminDao.getPaymentDetails();
	}

	/**
	 * View process payment.
	 * 
	 * @param vendorId
	 *            the vendor id
	 * @param invoiceId
	 *            the invoice id
	 * @param amount
	 *            the amount
	 * @return the model and view
	 */

	@RequestMapping(value = "/processPayment", method = RequestMethod.GET)
	public ModelAndView processPayment(HttpServletRequest request) {
		int vendorId = Integer.parseInt(request.getParameter("vendorID"));
		loggerInstance.logger.info(vendorId);
		double amount = Double.parseDouble(request.getParameter("amount"));
		String invoiceId = request.getParameter("invoiceID");
		String invoiceDate = request.getParameter("invoiceDate");
		loggerInstance.logger.info(invoiceId);
		loggerInstance.logger.info(invoiceDate);
		loggerInstance.logger.info(amount);
		loggerInstance.logger.info("Got request for process payment");
		HistoricalDataCriteria object = new HistoricalDataCriteria();
		return object.applyCriteria(vendorId, amount, invoiceId, invoiceDate);
	}
	
	/**
	 * Compute varience.
	 * 
	 * @param locale
	 *            the locale
	 * @param model
	 *            the model
	 * @param variance
	 *            the variance
	 * @param vendorID
	 *            the vendor ID
	 * @param payment
	 *            the payment
	 * @param invoiceNum
	 *            the invoice num
	 * @return the model and view
	 */
	@RequestMapping(value = "/variance", method = RequestMethod.GET)
	public ModelAndView computeVarience(HttpServletRequest request){
			String variance = request.getParameter("variance");
			int vendorID = Integer.parseInt(request.getParameter("vendorID"));
			double payment =Double.parseDouble(request.getParameter("payment"));
 			String invoiceNum = request.getParameter("invoiceNum");
			String invoiceDate = request.getParameter("invoiceDate");
		loggerInstance.logger.info("GOT REQUEST FOR VARIANCE");
		return adminDao.getVariance(variance, vendorID, payment, invoiceNum,
				invoiceDate);
	}

	/**
	 * Compute manual limit.
	 * 
	 * @param locale
	 *            the locale
	 * @param model
	 *            the model
	 * @param maximumLimit
	 *            the maximum limit
	 * @param vendorID
	 *            the vendor ID
	 * @param payment
	 *            the payment
	 * @param invoiceNum
	 *            the invoice num
	 * @return the model and view
	 * Locale locale, Model model,
			@RequestParam("minimumLimit") int minimumLimit,
			@RequestParam("maximumLimit") int maximumLimit,
			@RequestParam("vendorID") int vendorID,
			@RequestParam("payment") int payment,
			@RequestParam("invoiceNum") String invoiceNum,
			@RequestParam("invoiceDate") String invoiceDate
	 */
	@RequestMapping(value = "/manualLimit", method = RequestMethod.GET)
	public ModelAndView computeManualLimit(HttpServletRequest request) {
		int minimumLimit = Integer.parseInt(request.getParameter("minimumLimit"));
		int maximumLimit = Integer.parseInt(request.getParameter("maximumLimit"));
		int vendorID = Integer.parseInt(request.getParameter("vendorID"));
		double payment =Double.parseDouble(request.getParameter("payment"));
		String invoiceNum = request.getParameter("invoiceNum");
		String invoiceDate = request.getParameter("invoiceDate");
		return adminDao.manualLimit(minimumLimit, maximumLimit, vendorID,
				invoiceNum, payment, invoiceDate);
	}

	/**
	 * Update status.
	 * 
	 * @param locale
	 *            the locale
	 * @param model
	 *            the model
	 * @param invoiceNum
	 *            the invoice num
	 * @return the model and view
	 */
	@RequestMapping(value = "/updateStatus", method = RequestMethod.GET)
	public ModelAndView updateStatus(Locale locale, Model model,
			@RequestParam("invoiceNum") String invoiceNum) {
		VendorHistory.updateAggregateInvoiceRequest(invoiceNum, "Processed",
				"Satisfied Average Payment Criteria");
		ArrayList<Aggregateinvoiceinfo> invoiceList = adminDao
				.updateStatus(invoiceNum);
		ModelAndView modelObject = new ModelAndView("paneProcessing");
		modelObject.addObject("file", invoiceList);
		modelObject.addObject("message", "success");
		return modelObject;
	}

	@RequestMapping(value = "/exceptionCriteria", method = RequestMethod.GET)
	public ModelAndView exceptionCriteria(Locale locale, Model model,
			@RequestParam("vendorID") int vendorID,
			@RequestParam("payment") double payment,
			@RequestParam("invoiceNum") String invoiceNum,
			@RequestParam("exceptionAmount") double exceptionAmount,
			@RequestParam("invoiceDate") String invoiceDate) {
		ModelAndView modelObject = new ModelAndView("paneProcessing");
		loggerInstance.logger.info("vendorID" + vendorID);
		loggerInstance.logger.info("payment" + payment);
		loggerInstance.logger.info("invoiceNum" + invoiceNum);
		loggerInstance.logger.info("exceptionAmount" + exceptionAmount);
		loggerInstance.logger.info("invoiceDate" + invoiceDate);

		double pendingAmount = payment - exceptionAmount;

		// write update query here
		if (pendingAmount > 0) {
			EntityManager entityManagerObject = Database.getEntityManager();

			EntityTransaction updateTransaction = entityManagerObject
					.getTransaction();
			updateTransaction.begin();
			Query query = entityManagerObject
					.createQuery("UPDATE Aggregateinvoiceinfo  SET pendingPayment = ?1,paymentAmount = ?2,invoiceStatus='Processed',pane='Satisfied Exception Criteria' "
							+ "WHERE id= :parameter");
			query.setParameter(1, pendingAmount);
			query.setParameter(2, exceptionAmount);
			query.setParameter("parameter", Integer.parseInt(invoiceNum));
			query.executeUpdate();
			updateTransaction.commit();
			entityManagerObject.close();

		}
		
		ArrayList<Aggregateinvoiceinfo> unprocessedList = AddInvoiceToDB
				.returnUnprocessedInvoiceList();
		modelObject.addObject("message", "success");
		modelObject.addObject("file", unprocessedList);
		
		return modelObject;
	}

	@RequestMapping(value = "/getExceptionCriteriaView", method = RequestMethod.GET)
	public ModelAndView getExceptionCriteriaView(Locale locale, Model model,
			@RequestParam("vendorID") int vendorID,
			@RequestParam("payment") double payment,
			@RequestParam("invoiceNum") int invoiceNum,
			@RequestParam("invoiceDateDay") String invoiceDateDay,
			@RequestParam("invoiceDateMonth") String invoiceDateMonth,
			@RequestParam("invoiceDateYear") String invoiceDateYear) {
		ModelAndView modelObject = new ModelAndView("paneProcessing");
		ArrayList<String> resultList = new ArrayList<String>();

		resultList.add(String.valueOf(vendorID));

		resultList.add(String.valueOf(payment));

		resultList.add(String.valueOf(invoiceNum));

		resultList.add(invoiceDateYear + "-" + invoiceDateMonth + "-"
				+ invoiceDateDay);

		modelObject.addObject("vendorInfo", resultList);
		modelObject.addObject("paneNumber", "pane4");

		Map<String, String> historyMap = VendorHistory
				.getVendorHistory(vendorID);
		ArrayList<String> historyList = new ArrayList<String>();
		ArrayList<String> historyListPeriod = new ArrayList<String>();

		for (Entry<String, String> entry : historyMap.entrySet()) {
			String[] splittingMonth = entry.getKey().split("/");
			historyListPeriod.add(getMonthName(splittingMonth[1]) + "-"
					+ splittingMonth[0]);
			historyList.add(entry.getValue());
		}

		modelObject.addObject("vendorHistoryPeriod", historyListPeriod);
		modelObject.addObject("vendorHistory", historyList);

		loggerInstance.logger.info("Inside getExceptionCriteriaView ");

		loggerInstance.logger.info("vendorID " + vendorID);
		loggerInstance.logger.info("payment " + payment);
		loggerInstance.logger.info("invoiceNum " + invoiceNum);
		return modelObject;

	}
	@RequestMapping(value="/downloadFileByAdmin" , method = RequestMethod.GET)
	public ModelAndView viewprocessFile(@RequestParam("filename") String filename, ModelMap model, HttpServletResponse response){
		
		loggerInstance.logger.info("Starting file download");
		adminDao.downloadFileByAdmin(filename,response);
		loggerInstance.logger.info("Status of download file = ");
		//if(downloadFile)
			//return new ModelAndView("adminHome");
		//else
			return new ModelAndView("viewExcelFilesbyAdmin");				
	}
	
	@RequestMapping(value="/sendForApproval" , method = RequestMethod.POST)
	public ModelAndView addForApproval(HttpServletRequest request){
		String[] paymentIdArray = request.getParameterValues("vendorCode");
		loggerInstance.logger.info("Got request");
		loggerInstance.logger.info("Requesting for payment id ="+Arrays.toString(paymentIdArray));
		if(paymentIdArray.length>0){
			Database.addAveragePaymentRequest(paymentIdArray);
		}
		return adminDao.getPaymentDetails();				
	}
	
	private static String getMonthName(String splittingMonth) {
		String monthString;
		int month = Integer.parseInt(splittingMonth);
		switch (month) {
		case 0:
			monthString = "0";
			break;
		case 1:
			monthString = "Jan";
			break;
		case 2:
			monthString = "Feb";
			break;
		case 3:
			monthString = "Mar";
			break;
		case 4:
			monthString = "Apr";
			break;
		case 5:
			monthString = "May";
			break;
		case 6:
			monthString = "June";
			break;
		case 7:
			monthString = "July";
			break;
		case 8:
			monthString = "Aug";
			break;
		case 9:
			monthString = "Sep";
			break;
		case 10:
			monthString = "Oct";
			break;
		case 11:
			monthString = "Nov";
			break;
		case 12:
			monthString = "Dec";
			break;
		default:
			monthString = "Invalid month";
			break;
		}
		return monthString;
	}

}