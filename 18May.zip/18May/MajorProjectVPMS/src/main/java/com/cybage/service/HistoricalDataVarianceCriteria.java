package com.cybage.service;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cybage.configuration.LoggerClass;

// TODO: Auto-generated Javadoc
/**
 * The Class HistoricalDataVarianceCriteria.
 * @author palasht
 */
public class HistoricalDataVarianceCriteria {
	
	/** The Constant logger. */
	private static final LoggerClass loggerInstance = LoggerClass.getLoggerInstance();
	 
	/**
	 * Apply criteria.
	 *
	 * @param percentVariance the percent variance
	 * @param vendorCode the vendor code
	 * @param paymentAmount the payment amount
	 * @return the array list
	 */
	public ArrayList<String> applyCriteria(int percentVariance,int vendorCode,double paymentAmount,String invoiceDate){
		
		loggerInstance.logger.info("Inside variance");
		EntityManager entityManagerObject=Database.getEntityManager();			
		
		ArrayList<String> vendorInfo=new ArrayList<String>();
		
		vendorInfo.add(String.valueOf(vendorCode));
		vendorInfo.add(String.valueOf(paymentAmount));
		
		
		int newPayment=0;
		
		 StoredProcedureQuery storedProcedure = entityManagerObject.createStoredProcedureQuery("computeVariance");
			
		 
		 storedProcedure.registerStoredProcedureParameter("venID", Integer.class, ParameterMode.IN);

		 storedProcedure.registerStoredProcedureParameter("variancePercent", Integer.class, ParameterMode.IN);
		 storedProcedure.registerStoredProcedureParameter("newPayment", Integer.class, ParameterMode.OUT);
		 storedProcedure.setParameter("venID", vendorCode);
		 storedProcedure.setParameter("variancePercent", percentVariance);
		 
		storedProcedure.execute();

		newPayment = (Integer)storedProcedure.getOutputParameterValue("newPayment");

		loggerInstance.logger.info("newPayment: "+newPayment);
		entityManagerObject.close();
		 
		if(paymentAmount<=newPayment){
			loggerInstance.logger.info("Payment falls under the specified variance");
			//give pop up
			vendorInfo.add("success");
			vendorInfo.add(invoiceDate);
			return vendorInfo;
		}
		else{
			loggerInstance.logger.info("Payment exceeds the specified variance");
			// return Pane 3
			vendorInfo.add("fail");
			vendorInfo.add(invoiceDate);
			return vendorInfo;
		}
		
	}
}