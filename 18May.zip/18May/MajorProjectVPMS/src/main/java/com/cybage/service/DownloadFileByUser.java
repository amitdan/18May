package com.cybage.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;

import com.cybage.configuration.LoggerClass;


public class DownloadFileByUser {
private static final LoggerClass loggerInstance = LoggerClass.getLoggerInstance();	
	private static final String UPLOAD_DIRECTORY = System.getProperty("user.dir")+"\\Files\\";
	
	public boolean downloadFileByuser(String filename, HttpServletResponse response) {
		loggerInstance.logger.info("File downloading started"+filename);
		boolean result=false;
		String filePathToBeServed = UPLOAD_DIRECTORY+filename+".xlsx"; 
	        File fileToDownload = new File(filePathToBeServed);
	        InputStream inputStream = null;
		try {
			inputStream = new FileInputStream(fileToDownload);
	       	
	        response.setContentType("application/xlsx");
	        response.setHeader("Content-Disposition", "attachment; filename="+filename+".xlsx"); 
	        OutputStream outputStream = response.getOutputStream();
	        IOUtils.copy(inputStream, outputStream);
	        loggerInstance.logger.info("File coopied");
	        response.flushBuffer();
	        loggerInstance.logger.info("Response flushed");
	        inputStream.close();
	        loggerInstance.logger.info("input stream closed");
	        outputStream.flush();
	        loggerInstance.logger.info("outputStream flushed");
	        outputStream.close();
	        loggerInstance.logger.info("outputStream closed");
	        result=true;
	    } catch (Exception e){
	    	loggerInstance.logger.error("Request could not be completed at this moment. Please try again."+e);
	    }
		finally{
			if(inputStream!=null){
			try {
				inputStream.close();
			} catch (IOException e) {
			loggerInstance.logger.error(e);
			}
			}
		}
		return result;
	}

}
