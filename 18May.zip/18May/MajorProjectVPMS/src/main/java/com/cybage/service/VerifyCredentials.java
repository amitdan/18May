package com.cybage.service;

import java.util.Hashtable;



import javax.crypto.SecretKey;
import javax.naming.Context;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;



public class VerifyCredentials {
	static DirContext ldapContext;
	public boolean validate(String username,byte[] encryptedPassword,HttpServletRequest request,SecretKey secretKey) 
	{
		try{
			Hashtable<String, String> ldapEnv = new Hashtable<String, String>(11);
			
			ldapEnv.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
			ldapEnv.put(Context.PROVIDER_URL,  "ldap://ct-dc-1-1.cybage.com");
			ldapEnv.put(Context.SECURITY_AUTHENTICATION, "simple");
			String domain="@cybage.com"; 
			HttpSession session=request.getSession();
			session.setAttribute("username", username);
			ldapEnv.put(Context.SECURITY_PRINCIPAL, username.concat(domain));
			ldapEnv.put(Context.SECURITY_CREDENTIALS,EncryptionDecreption.decryptText(encryptedPassword, secretKey));
			ldapContext = new InitialDirContext(ldapEnv);
			return true;
		}catch(Exception e)
		{
			return false;
		}
	}
}
